# Podcast Invaders

A retro-style space invaders game with a podcast theme, built with React, TypeScript, and Tailwind CSS.

## Features

- Classic space invaders gameplay mechanics
- Retro sound effects and background music
- Responsive controls
- Score tracking
- Sound and music toggle options
- Pause functionality

## Technologies Used

- React
- TypeScript
- Tailwind CSS
- Vite
- Lucide React Icons

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

## Game Controls

- Arrow Left/Right: Move player
- Space: Shoot
- P: Pause game
- M: Toggle sound effects
- Music icon: Toggle background music

## Development

This project uses:
- Vite for fast development and building
- TypeScript for type safety
- ESLint for code quality
- Tailwind CSS for styling
- Lucide React for icons

## Building for Production

To create a production build:

```bash
npm run build
```

## License

MIT
export interface Entity {
  x: number;
  y: number;
  id: string;
  moveDelay: number;
  lastMove: number;
}

export interface Bullet {
  x: number;
  y: number;
  id: string;
}

export interface GameSounds {
  shoot: HTMLAudioElement;
  explosion: HTMLAudioElement;
  enemyShoot: HTMLAudioElement;
  background: HTMLAudioElement;
}
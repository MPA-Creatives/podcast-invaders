import { GameSounds } from '../types/game';
import { SOUND_URLS } from '../constants/game';

export const initializeSounds = (): GameSounds => {
  const sounds = {
    shoot: new Audio(SOUND_URLS.shoot),
    explosion: new Audio(SOUND_URLS.explosion),
    enemyShoot: new Audio(SOUND_URLS.enemyShoot),
    background: new Audio(SOUND_URLS.background)
  };

  Object.values(sounds).forEach(sound => {
    sound.volume = 0.3;
    sound.load();
  });

  sounds.background.loop = true;
  sounds.background.volume = 0.1;

  return sounds;
};
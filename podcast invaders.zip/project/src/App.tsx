import React from 'react';
import Game from './components/Game';

function App() {
  return (
    <div className="min-h-screen bg-gray-800 flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold text-white mb-8">Podcast Invaders</h1>
      <div className="bg-gray-700 p-4 rounded-lg shadow-2xl">
        <Game />
      </div>
      <div className="mt-8 text-white text-center">
        <p className="mb-2">Controls:</p>
        <p>← → Arrow keys to move</p>
        <p>Space to shoot</p>
      </div>
    </div>
  );
}

export default App;
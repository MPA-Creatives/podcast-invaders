export const GAME_WIDTH = 800;
export const GAME_HEIGHT = 600;
export const PLAYER_SPEED = 5;
export const ENEMY_ROWS = 3;
export const ENEMIES_PER_ROW = 8;
export const BULLET_SPEED = 7;
export const ENEMY_BULLET_SPEED = 4;
export const ENEMY_MOVE_DISTANCE = 20;
export const BASE_MOVE_INTERVAL = 1000;

export const SOUND_URLS = {
  shoot: 'https://www.soundjay.com/mechanical/sounds/laser-gun-19sf.mp3',
  explosion: 'https://www.soundjay.com/explosion/sounds/explosion-01.mp3',
  enemyShoot: 'https://www.soundjay.com/mechanical/sounds/ray-gun-01.mp3',
  background: 'https://www.soundjay.com/ambient/sounds/video-game-music-01.mp3'
};
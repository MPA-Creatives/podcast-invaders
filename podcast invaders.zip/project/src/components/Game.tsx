import React, { useState, useEffect, useCallback } from 'react';
import { Mic, Headphones, Pause, Play, Mic2, Volume2, VolumeX, Music, Music2 } from 'lucide-react';
import { Entity, Bullet, GameSounds } from '../types/game';
import { 
  GAME_WIDTH, 
  GAME_HEIGHT, 
  PLAYER_SPEED, 
  ENEMY_ROWS, 
  ENEMIES_PER_ROW,
  BULLET_SPEED,
  ENEMY_BULLET_SPEED,
  ENEMY_MOVE_DISTANCE,
  BASE_MOVE_INTERVAL
} from '../constants/game';
import { initializeSounds } from '../utils/sound';

// Initialize sounds immediately
const SOUNDS: GameSounds = initializeSounds();

export default function Game() {
  const [gameStarted, setGameStarted] = useState(false);
  const [player, setPlayer] = useState({ x: GAME_WIDTH / 2, y: GAME_HEIGHT - 50 });
  const [enemies, setEnemies] = useState<Entity[]>([]);
  const [bullets, setBullets] = useState<Bullet[]>([]);
  const [enemyBullets, setEnemyBullets] = useState<Bullet[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [isMovingLeft, setIsMovingLeft] = useState(false);
  const [isMovingRight, setIsMovingRight] = useState(false);
  const [enemyDirection, setEnemyDirection] = useState(1);
  const [isPaused, setIsPaused] = useState(false);
  const [isSoundMuted, setIsSoundMuted] = useState(false);
  const [isMusicMuted, setIsMusicMuted] = useState(false);

  // Start background music on first user interaction
  const startBackgroundMusic = useCallback(() => {
    const playMusic = () => {
      SOUNDS.background.play().catch(() => {});
      document.removeEventListener('click', playMusic);
      document.removeEventListener('keydown', playMusic);
    };
    document.addEventListener('click', playMusic);
    document.addEventListener('keydown', playMusic);
  }, []);

  useEffect(() => {
    startBackgroundMusic();
    return () => {
      SOUNDS.background.pause();
      SOUNDS.background.currentTime = 0;
    };
  }, [startBackgroundMusic]);

  // Sound controls
  const toggleSound = useCallback(() => {
    setIsSoundMuted(prev => {
      const newMuted = !prev;
      Object.entries(SOUNDS).forEach(([key, sound]) => {
        if (key !== 'background') {
          sound.muted = newMuted;
        }
      });
      return newMuted;
    });
  }, []);

  const toggleMusic = useCallback(() => {
    setIsMusicMuted(prev => {
      const newMuted = !prev;
      SOUNDS.background.muted = newMuted;
      if (!newMuted) {
        SOUNDS.background.play().catch(() => {});
      }
      return newMuted;
    });
  }, []);

  // Play sound effect with error handling
  const playSound = useCallback((sound: HTMLAudioElement) => {
    if (!isSoundMuted) {
      sound.currentTime = 0;
      sound.play().catch(() => {});
    }
  }, [isSoundMuted]);

  // Initialize game
  const startGame = useCallback(() => {
    setGameStarted(true);
    setGameOver(false);
    setScore(0);
    setPlayer({ x: GAME_WIDTH / 2, y: GAME_HEIGHT - 50 });
    setBullets([]);
    setEnemyBullets([]);
    setEnemyDirection(1);
    setIsPaused(false);
    
    const newEnemies: Entity[] = [];
    for (let row = 0; row < ENEMY_ROWS; row++) {
      for (let col = 0; col < ENEMIES_PER_ROW; col++) {
        newEnemies.push({
          x: col * (GAME_WIDTH / ENEMIES_PER_ROW) + 50,
          y: row * 60 + 50,
          id: `enemy-${row}-${col}`,
          moveDelay: BASE_MOVE_INTERVAL + Math.random() * 500,
          lastMove: Date.now(),
        });
      }
    }
    setEnemies(newEnemies);
  }, []);

  // Handle keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!gameStarted || gameOver) return;
      
      if (e.key === 'ArrowLeft') setIsMovingLeft(true);
      if (e.key === 'ArrowRight') setIsMovingRight(true);
      if (e.code === 'Space') {
        e.preventDefault();
        if (!isPaused) {
          playSound(SOUNDS.shoot);
          setBullets(prev => [...prev, {
            x: player.x,
            y: player.y,
            id: Date.now().toString(),
          }]);
        }
      }
      if (e.key === 'p' || e.key === 'P') {
        setIsPaused(prev => !prev);
      }
      if (e.key === 'm' || e.key === 'M') {
        toggleSound();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') setIsMovingLeft(false);
      if (e.key === 'ArrowRight') setIsMovingRight(false);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameStarted, gameOver, player, isPaused, playSound, toggleSound]);

  // Enemy movement
  useEffect(() => {
    if (!gameStarted || gameOver || isPaused) return;

    const moveEnemies = () => {
      const now = Date.now();
      let needsDirectionChange = false;
      
      setEnemies(prev => {
        const updatedEnemies = prev.map(enemy => {
          if (now - enemy.lastMove < enemy.moveDelay) {
            return enemy;
          }

          const newX = enemy.x + (ENEMY_MOVE_DISTANCE * enemyDirection);
          
          if (newX <= 30 || newX >= GAME_WIDTH - 30) {
            needsDirectionChange = true;
          }

          return {
            ...enemy,
            x: needsDirectionChange ? enemy.x : newX,
            y: needsDirectionChange ? enemy.y + 20 : enemy.y,
            lastMove: now,
            moveDelay: BASE_MOVE_INTERVAL + Math.random() * 500,
          };
        });

        return updatedEnemies;
      });

      if (needsDirectionChange) {
        setEnemyDirection(prev => prev * -1);
      }
    };

    const moveInterval = setInterval(moveEnemies, 100);
    return () => clearInterval(moveInterval);
  }, [gameStarted, gameOver, enemyDirection, isPaused]);

  // Game loop
  useEffect(() => {
    if (!gameStarted || gameOver || isPaused) return;

    const gameLoop = setInterval(() => {
      setPlayer(prev => ({
        x: Math.max(30, Math.min(GAME_WIDTH - 30, prev.x + 
          (isMovingLeft ? -PLAYER_SPEED : 0) + 
          (isMovingRight ? PLAYER_SPEED : 0))),
        y: prev.y,
      }));

      setBullets(prev => 
        prev.filter(bullet => bullet.y > 0)
           .map(bullet => ({ ...bullet, y: bullet.y - BULLET_SPEED }))
      );

      setEnemyBullets(prev =>
        prev.filter(bullet => bullet.y < GAME_HEIGHT)
           .map(bullet => ({ ...bullet, y: bullet.y + ENEMY_BULLET_SPEED }))
      );

      setBullets(prev => {
        const newBullets = [...prev];
        setEnemies(prevEnemies => {
          const newEnemies = prevEnemies.filter(enemy => {
            const hitByBullet = newBullets.some(bullet => 
              Math.abs(bullet.x - enemy.x) < 30 && 
              Math.abs(bullet.y - enemy.y) < 30
            );
            if (hitByBullet) {
              playSound(SOUNDS.explosion);
              setScore(s => s + 100);
              return false;
            }
            return true;
          });
          return newEnemies;
        });
        return newBullets.filter(bullet => 
          !enemies.some(enemy => 
            Math.abs(bullet.x - enemy.x) < 30 && 
            Math.abs(bullet.y - enemy.y) < 30
          )
        );
      });

      setEnemyBullets(prev => {
        const newEnemyBullets = prev.filter(bullet => 
          !(Math.abs(bullet.x - player.x) < 30 && 
            Math.abs(bullet.y - player.y) < 30)
        );
        if (newEnemyBullets.length !== prev.length) {
          playSound(SOUNDS.explosion);
          setGameOver(true);
        }
        return newEnemyBullets;
      });

      if (enemies.some(enemy => enemy.y >= GAME_HEIGHT - 100)) {
        setGameOver(true);
      }

      if (enemies.length === 0) {
        setGameOver(true);
      }
    }, 16);

    return () => clearInterval(gameLoop);
  }, [gameStarted, gameOver, enemies, player, isMovingLeft, isMovingRight, isPaused, playSound]);

  // Enemy shooting
  useEffect(() => {
    if (!gameStarted || gameOver || isPaused) return;

    const enemyShootInterval = setInterval(() => {
      if (enemies.length > 0) {
        enemies.forEach(enemy => {
          if (Math.random() < 0.1) {
            playSound(SOUNDS.enemyShoot);
            setEnemyBullets(prev => [...prev, {
              x: enemy.x,
              y: enemy.y,
              id: Date.now().toString() + Math.random(),
            }]);
          }
        });
      }
    }, 1000);

    return () => clearInterval(enemyShootInterval);
  }, [gameStarted, enemies, gameOver, isPaused, playSound]);

  if (!gameStarted) {
    return (
      <div className="relative w-[800px] h-[600px] bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl text-white mb-8">Podcast Invaders</h1>
          <button
            onClick={startGame}
            className="px-8 py-4 bg-blue-500 text-white text-xl rounded-lg hover:bg-blue-600 transition"
          >
            Start Game
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-[800px] h-[600px] bg-gray-900 overflow-hidden">
      {/* Score and Controls */}
      <div className="absolute top-4 left-4 text-white">
        <div className="text-xl mb-2">Score: {score}</div>
        <div className="text-sm opacity-70">
          <div>← → Arrow keys to move</div>
          <div>Space to shoot</div>
          <div>P to pause</div>
          <div>M to mute sound effects</div>
        </div>
      </div>

      {/* Sound and Pause Controls */}
      <div className="absolute top-4 right-4 flex gap-4">
        <button
          onClick={toggleMusic}
          className="text-white hover:text-blue-400 transition-colors"
          title="Toggle Music"
        >
          {isMusicMuted ? <Music className="w-6 h-6" /> : <Music2 className="w-6 h-6" />}
        </button>
        <button
          onClick={toggleSound}
          className="text-white hover:text-blue-400 transition-colors"
          title="Toggle Sound Effects"
        >
          {isSoundMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
        </button>
        <button
          onClick={() => setIsPaused(p => !p)}
          className="text-white hover:text-blue-400 transition-colors"
          title="Pause Game"
        >
          {isPaused ? <Play className="w-6 h-6" /> : <Pause className="w-6 h-6" />}
        </button>
      </div>

      {/* Player */}
      <div 
        className="absolute"
        style={{ 
          transform: `translate(${player.x}px, ${player.y}px)`,
          transition: 'transform 0.05s linear'
        }}
      >
        <Mic2 
          className="w-8 h-8 text-white"
        />
      </div>

      {/* Enemies */}
      {enemies.map(enemy => (
        <div
          key={enemy.id}
          className="absolute text-red-500"
          style={{ 
            transform: `translate(${enemy.x}px, ${enemy.y}px)`,
            transition: 'transform 0.5s ease-in-out'
          }}
        >
          <Headphones className="w-8 h-8" />
        </div>
      ))}

      {/* Player Bullets */}
      {bullets.map(bullet => (
        <div
          key={bullet.id}
          className="absolute w-2 h-4 bg-yellow-400 rounded"
          style={{ 
            transform: `translate(${bullet.x}px, ${bullet.y}px)`,
          }}
        />
      ))}

      {/* Enemy Bullets */}
      {enemyBullets.map(bullet => (
        <div
          key={bullet.id}
          className="absolute text-red-400"
          style={{ 
            transform: `translate(${bullet.x}px, ${bullet.y}px)`,
          }}
        >
          <Mic className="w-4 h-4" />
        </div>
      ))}

      {/* Pause Overlay */}
      {isPaused && !gameOver && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="text-center text-white">
            <h2 className="text-4xl mb-4">PAUSED</h2>
            <p className="text-xl">Press P to resume</p>
          </div>
        </div>
      )}

      {/* Game Over Screen */}
      {gameOver && (
        <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-4xl text-white mb-4">
              {enemies.length === 0 ? 'Victory!' : 'Game Over!'}
            </h2>
            <p className="text-2xl text-white mb-8">Final Score: {score}</p>
            <button
              onClick={startGame}
              className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
            >
              Play Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
}